using System.Text.Json;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddHttpClient();
builder.Services.AddControllers();

var app = builder.Build();
var logger = app.Logger;

app.MapControllers();

app.MapGet("/health", () => new { status = "healthy", service = "userservice" });
app.MapGet("/something/health", () => new { status = "healthy", service = "userservice" });
app.MapGet("/maulik/health", () => new { status = "healthy", service = "userservice" });

// Auth endpoint
app.MapPost("/auth/login", (LoginRequest request) =>
{
    logger.LogInformation("Login attempt for user: {Username}", request.Username);
    
    // Simple validation (in real app, check against database)
    if (request.Username == "admin" && request.Password == "password")
    {
        var jwtKey = "MySecretKeyForJWTTokenGeneration123456789";
        var key = Encoding.ASCII.GetBytes(jwtKey);
        
        var tokenHandler = new JwtSecurityTokenHandler();
        var tokenDescriptor = new SecurityTokenDescriptor
        {
            Subject = new ClaimsIdentity(new[] { new Claim("username", request.Username) }),
            Expires = DateTime.UtcNow.AddHours(1),
            SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
        };
        
        var token = tokenHandler.CreateToken(tokenDescriptor);
        var tokenString = tokenHandler.WriteToken(token);
        
        logger.LogInformation("Login successful for user: {Username}", request.Username);
        return Results.Ok(new { Token = tokenString, Username = request.Username });
    }
    
    logger.LogWarning("Login failed for user: {Username}", request.Username);
    return Results.Unauthorized();
});

app.MapGet("/users/{id}", async (int id, HttpClient httpClient) =>
{
    logger.LogInformation("Fetching user with ID: {UserId}", id);
    
    var user = new { Id = id, Name = $"User{id}", Email = $"user{id}@example.com" };
    
    try
    {
        logger.LogInformation("Calling OrderService for user: {UserId}", id);
        var ordersResponse = await httpClient.GetStringAsync($"http://orderservice:9901/orders/user/{id}");
        var orders = JsonSerializer.Deserialize<object[]>(ordersResponse);
        
        logger.LogInformation("Successfully retrieved {OrderCount} orders for user: {UserId}", orders?.Length ?? 0, id);
        return new { User = user, Orders = orders };
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "Error fetching orders for user: {UserId}", id);
        return new { User = user, Orders = Array.Empty<object>() };
    }
});

app.Run();

public record LoginRequest(string Username, string Password);