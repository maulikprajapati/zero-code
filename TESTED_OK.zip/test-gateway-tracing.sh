#!/bin/bash

echo "Testing API Gateway with Distributed Tracing..."

# Test through API Gateway
echo "1. Testing user endpoint through API Gateway:"
curl -X GET "http://localhost:8082/api/users/123" -H "Content-Type: application/json"

echo -e "\n\n2. Testing direct OrderService call through API Gateway:"
curl -X GET "http://localhost:8082/api/orders/user/123" -H "Content-Type: application/json"

echo -e "\n\n3. Testing health check:"
curl -X GET "http://localhost:8082/health" -H "Content-Type: application/json"

echo -e "\n\nTraces should now be visible in Grafana at http://localhost:3000"
echo "Service names in traces: apigateway, userservice, orderservice"