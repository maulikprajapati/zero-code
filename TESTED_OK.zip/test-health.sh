#!/bin/bash

echo "Testing health endpoints..."

# Get service URLs
USERSERVICE_URL=$(minikube service userservice -n tracing --url)
ORDERSERVICE_URL=$(minikube service orderservice -n tracing --url)

echo "UserService Health: $USERSERVICE_URL/health"
curl -s "$USERSERVICE_URL/health" | jq .

echo -e "\nOrderService Health (via port-forward):"
echo "Run: kubectl port-forward svc/orderservice 9901:9901 -n tracing"
echo "Then: curl http://localhost:9901/health"

echo -e "\nTesting regular endpoints (these should be traced):"
curl -s "$USERSERVICE_URL/users/123" | jq .

echo -e "\nHealth endpoints should NOT appear in Grafana Tempo traces!"